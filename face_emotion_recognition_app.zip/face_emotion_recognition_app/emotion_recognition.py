import cv2
import numpy as np
from deepface import DeepFace
import pandas as pd
import os
from datetime import datetime

def detect_faces(image):
    
    try:
        detected_faces = DeepFace.extract_faces(img_path=image, detector_backend='ssd', enforce_detection=False)
        faces = []
        for face in detected_faces:
            if 'facial_area' in face:
                fa = face['facial_area']
                faces.append((fa['x'], fa['y'], fa['w'], fa['h']))
        return faces
    except Exception as e:
        print(f"Error detecting faces: {e}")
        return []

def analyze_emotion(face_image):

    try:
        result = DeepFace.analyze(face_image, actions=['emotion'], enforce_detection=False)
        emotion = result[0]['dominant_emotion']
        return emotion
    except Exception as e:
        print(f"Error analyzing emotion: {e}")
        return "Unknown"

def process_image(image):

    faces = detect_faces(image)
    emotions = []
    for (x, y, w, h) in faces:
        face_roi = image[y:y+h, x:x+w]
        emotion = analyze_emotion(face_roi)
        emotions.append(emotion)
        cv2.rectangle(image, (x, y), (x+w, y+h), (255, 0, 0), 2)
        cv2.putText(image, emotion, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)
    return image, emotions

def log_emotion(emotion):

    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    data = {'timestamp': [timestamp], 'emotion': [emotion]}
    df = pd.DataFrame(data)
    if not os.path.exists('emotion_history.csv'):
        df.to_csv('emotion_history.csv', index=False)
    else:
        df.to_csv('emotion_history.csv', mode='a', header=False, index=False)

def real_time_emotion_detection():

    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam.")
        return

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        processed_frame, emotions = process_image(frame)
        for emotion in emotions:
            log_emotion(emotion)

        cv2.imshow('Emotion Recognition', processed_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    real_time_emotion_detection()
